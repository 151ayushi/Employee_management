#output snapshot
# List of All Users
![Screenshot (157)](https://user-images.githubusercontent.com/94095778/229090753-813a5768-7d02-49a5-a1cd-9eac390e0a7f.png)

# Add User
![Screenshot (159)](https://user-images.githubusercontent.com/94095778/229090686-89e57f0d-d70f-49e2-80de-50a0a24f3bf5.png)

# View User details
![Screenshot (160)](https://user-images.githubusercontent.com/94095778/229090789-87a1721a-9679-4fb7-aab1-d1e2d1d8f7bb.png)

# Update user
![Screenshot (158)](https://user-images.githubusercontent.com/94095778/229090819-0e24541b-a7dc-4d23-9011-ea15b2d53661.png)




# AngFrontendSql

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 15.2.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
