export class Employee {
        id: number;
        fullName: string;
        emailId: string;
        mobile: string;
        dateOfBirth: Date;
        address: String;
}

 