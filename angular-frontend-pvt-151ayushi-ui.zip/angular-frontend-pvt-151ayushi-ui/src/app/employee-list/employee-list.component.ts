import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit{
  employees: Employee[];

  // constructor(private employeeService: EmployeeService, private router: Router){ }

  constructor(private employeeService: EmployeeService,
    private router: Router) { }

  ngOnInit(): void {

    this.getEmployees();
    // this.employeeService.getEmployeesList().subscribe((data:Employee[]) => {
    //   this.employees = data;
    // });
      
  }


  private getEmployees(){
    // console.log("hello")
    this.employeeService.getEmployeesList().subscribe(data => {
      this.employees = data;
    });
  }

  employeeDetails(Id: number){
    this.router.navigate(['employee-details', Id]);
  }

  updateEmployee(Id: number){
    this.router.navigate(['update-employee', Id]);
  }

  deleteEmployee(Id: number){
    this.employeeService.deleteEmployee(Id).subscribe(data =>{
      console.log(data);
      this.getEmployees();
  
    })
  }


  

}
