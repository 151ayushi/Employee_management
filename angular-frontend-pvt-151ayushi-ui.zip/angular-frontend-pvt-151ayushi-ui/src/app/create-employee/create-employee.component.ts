import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  
  employee: Employee = new Employee();
  constructor( private employeeService: EmployeeService, private router: Router){}

  registerForm=new FormGroup({
    fullName:new FormControl('',[Validators.required,Validators.minLength(3)]),
    emailId:new FormControl('',[Validators.required,Validators.email]),
    mobile:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
    dateOfBirth:new FormControl('',[Validators.required]),
    address:new FormControl('',[Validators.required,Validators.minLength(6)]),
    
  });

  ngOnInit(): void{

  }

  saveEmployee(){
    this.employeeService.createEmployee(this.employee).subscribe(data =>{
      console.log(data);
      this.goToEmployeeList();
    },
    error => console.log(error));
  }

  get fullName(){
    return this.registerForm.get('fullName');
  }
  get emailId(){
    return this.registerForm.get('emailId');
  }
  get mobile(){
    return this.registerForm.get('mobile');
  }

  get dateOfBirth(){
    return this.registerForm.get('dateOfBirth');
  }
  get address(){
    return this.registerForm.get('address');
  }
 

  goToEmployeeList(){
    this.router.navigate(['/employees']);

  }

  onSubmit(){
    console.log(this.employee);
    this.saveEmployee();

  }

}
