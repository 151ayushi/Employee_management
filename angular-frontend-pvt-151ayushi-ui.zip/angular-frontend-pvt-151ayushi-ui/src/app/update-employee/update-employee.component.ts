import { Component,OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit{
  id: number;
  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router) { }

    registerForm=new FormGroup({
      fullName:new FormControl('',[Validators.required,Validators.minLength(3)]),
      emailId:new FormControl('',[Validators.required,Validators.email]),
      mobile:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
      dateOfBirth:new FormControl('',[Validators.required]),
      address:new FormControl('',[Validators.required,Validators.minLength(6)]),
      
    });

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.employeeService.getEmployeeById(this.id).subscribe(data => {
      this.employee = data;
    }, error => console.log(error));
  }

  // updateEmployee(){

  //   this.employeeService.updateEmployee(this.Id, this.employee).subscribe(data => {
  //     console.log(data);
  //     this.employee = new Employee();
  //     this.gotoList();
  //   }, error => console.log(error));
  // }

  // onSubmit(){
  //   this.updateEmployee();
  // }


  get fullName(){
    return this.registerForm.get('fullName');
  }
  get emailId(){
    return this.registerForm.get('emailId');
  }
  get mobile(){
    return this.registerForm.get('mobile');
  }

  get dateOfBirth(){
    return this.registerForm.get('dateOfBirth');
  }
  get address(){
    return this.registerForm.get('address');
  }

  goToEmployeeList(){
    this.router.navigate(['/employees']);

  }

  onSubmit(){
    this.employeeService.updateEmployee(this.id, this.employee).subscribe( data =>{
      // console.log(data);
      this.goToEmployeeList();
    }
    , error => console.log(error));
  }

 
}



