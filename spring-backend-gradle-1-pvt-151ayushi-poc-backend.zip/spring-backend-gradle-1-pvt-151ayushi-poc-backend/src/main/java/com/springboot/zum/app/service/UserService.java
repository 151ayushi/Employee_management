
package com.springboot.zum.app.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
//import com.springboot.zum.app.Exception.ApplicationExceptionHandler;
//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PutMapping;

import com.springboot.zum.app.Exception.ResourceNotFoundException;
import com.springboot.zum.app.model.User;
import com.springboot.zum.app.repository.UserRepository;

@Service

public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	
	public User saveUser(User user) {
		
		return userRepository.save(user);
	}
	
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}
	
	


	public User getUser(Long Id){
		

		return userRepository.findById(Id).orElseThrow(() ->  new ResourceNotFoundException("Employee not exist with id: " + Id));
				
				
				

		
	}
	

	public User updateUser(Long Id, User userDetails) {
		User user = userRepository.findById(Id).orElseThrow(() ->  new ResourceNotFoundException("Employee not exist with id: " + Id));
		
		user.setFullName(userDetails.getFullName());
		user.setEmailId(userDetails.getEmailId());
		user.setMobile(userDetails.getMobile());
		user.setDateOfBirth(userDetails.getDateOfBirth());
		user.setAddress(userDetails.getAddress());

		return userRepository.save(user);
	}
	
	public void removeUser(long Id){

      userRepository.deleteById(Id);
  }
	

	
	
}
