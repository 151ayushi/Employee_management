package com.springboot.zum.app.model;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "`TEST_USER_INFO`")
@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class User {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserId")
    private Long Id; 
	
    @NotNull(message = "username should not be null")
    @Size(min = 3, message="please enter atleast 3 char")
    @Column(name = "fullname",nullable=false)
    private String fullName;
    
    @NotNull(message = "email should not be null")
    @Email(message = "invalid email address")
    @Column(name = "emailId",nullable=false)
    private String emailId;
     
    @Pattern(regexp = "^\\d{10}$", message = "Invalid mobile number")
    @Column(name = "mobile",nullable=false)
    private String mobile;
    
    
   
    @Column(name = "dateOfBirth")
    private Date dateOfBirth;
    
    @Column(name = "address")
    private String address;
    
    public User() {
    	
    }

	public User(String fullName, String emailId, String mobile, Date dateOfBirth, String address) {
		super();
		this.fullName = fullName;
		this.emailId = emailId;
		this.mobile = mobile;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		this.Id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
    
    

}
