package com.springboot.zum.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootBackendSql2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBackendSql2Application.class, args);
	}

}
