package com.springboot.zum.app.controller;

import java.util.List;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.zum.app.Exception.ResourceNotFoundException;
import com.springboot.zum.app.model.User;
import com.springboot.zum.app.repository.UserRepository;
//import com.springboot.zum.app.service.HashMap;
import com.springboot.zum.app.service.UserService;

@CrossOrigin(origins = "http://localhost:4200/")
@RestController
@RequestMapping("/api")

public class UserController {
	
	@Autowired
	private UserService userService;

	
	
	@PostMapping("/addusers")
	public ResponseEntity<User> saveUser(@RequestBody @Valid User user){
		return new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);
		
	}
	
	@GetMapping("/users")
	public ResponseEntity<List<User>> getAllUsers(){
		return ResponseEntity.ok(userService.getAllUsers());
	}
	
	
	@GetMapping("{Id}")
	public ResponseEntity<User> getUser(@PathVariable Long Id){
		return ResponseEntity.ok(userService.getUser(Id));
	}

	
	@PutMapping("{Id}")
	public ResponseEntity<User> updateUser(@PathVariable Long Id,@RequestBody User userDetails) {
		return ResponseEntity.ok(userService.updateUser(Id, userDetails));
		
	}
	
	@DeleteMapping("{Id}")
	public String deleteUser(@PathVariable("Id") Long Id){
		userService.removeUser(Id);

		return "deleted";
	}
	


}
