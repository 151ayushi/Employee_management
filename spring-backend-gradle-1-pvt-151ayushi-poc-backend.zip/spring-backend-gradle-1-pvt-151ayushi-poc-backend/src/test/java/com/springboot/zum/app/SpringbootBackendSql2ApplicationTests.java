package com.springboot.zum.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBackendSql2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
