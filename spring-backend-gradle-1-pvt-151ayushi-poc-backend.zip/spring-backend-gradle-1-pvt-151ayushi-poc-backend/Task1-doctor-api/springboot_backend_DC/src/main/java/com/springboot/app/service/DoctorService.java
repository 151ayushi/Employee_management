package com.springboot.app.service;

import java.util.List;
import java.util.Optional;

import com.springboot.app.model.Category;
import com.springboot.app.model.Doctor;

public interface DoctorService {
	
	Doctor addDoctor(Doctor doctor);
    List<Doctor> getAllDoctors();
    List<Doctor> getDoctorsByCategory(String categoryName);
    List<Doctor> getDoctorsByCId(Long CategoryId);



}



