package com.springboot.app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.app.model.Category;
import com.springboot.app.model.Doctor;
import com.springboot.app.repository.DoctorRepository;
import com.springboot.app.service.DoctorService;

@Service

public class DoctorServiceImpl implements DoctorService{
	
	 @Autowired
	    private DoctorRepository doctorRepository;

	    @Override
	    public Doctor addDoctor(Doctor doctor) {
	        return doctorRepository.save(doctor);
	    }

	    @Override
	    public List<Doctor> getAllDoctors() {
	        return doctorRepository.findAll();
	    }

	    @Override
	    public List<Doctor> getDoctorsByCategory(String categoryName) {
	        return doctorRepository.findByCategoryCategoryName(categoryName);
	    }
	    
	    @Override
	    public List<Doctor> getDoctorsByCId(Long id) {
	        return doctorRepository.findByCategoryId(id);
	    }
//	    
//	    @Override
//	    public List<Doctor> getDoctorsByCategory(Category category) {
//	        return doctorRepository.findByCategoryCategoryName(category);
//	    }



}
