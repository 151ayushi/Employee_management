package com.springboot.app.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.springboot.app.model.Category;
import com.springboot.app.model.Doctor;
@Repository

public interface DoctorRepository extends JpaRepository<Doctor, Long>{
	
//	List<Doctor> findByCategoryName(String categoryName);
//	List<Doctor> findByCategoryCategoryName(String categoryName);
//	List<Doctor> findByCategoryName(String categoryName);

	List<Doctor> findByCategoryCategoryName(String categoryName);
	List<Doctor> findByCategoryCategoryName(Category category);
//	List<Doctor> findByCategoryCategoryName(Category category);
	List<Doctor> findByCategoryId(Long id);
    
	

}
