package com.springboot.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.app.model.Category;
import com.springboot.app.model.Doctor;
//import com.springboot.app.service.DoctorService;
import com.springboot.app.service.DoctorService;

import jakarta.persistence.Id;


//@CrossOrigin(origins = "http://localhost:4200/")
@RestController
@RequestMapping("/doctors")

public class DoctorController {
	
	  @Autowired
	    private DoctorService doctorService;

	    
	    
	    @PostMapping
	    public Doctor addDoctor(@RequestBody Doctor doctor) {                                                                                                                 
	        return doctorService.addDoctor(doctor);
	    }

	    @GetMapping
	    public List<Doctor> getAllDoctors() {
	        return doctorService.getAllDoctors();
	    }


	    
	    @GetMapping("/category")
	    public List<Doctor> getDoctorsByCategory(@RequestParam String categoryName) {
	        return doctorService.getDoctorsByCategory(categoryName);
	    }
	    
	    @GetMapping("/categoryId")
	    public List<Doctor> getDoctorsByCId(@RequestParam Long id) {
	        return doctorService.getDoctorsByCId(id);
	    }
	    
//	    
//	    @GetMapping("/category")
//	    public List<Doctor> getDoctorsByCategory(@RequestBody Category category) {
//	        return doctorService.getDoctorsByCategory(category);
//	    }
//	    

}
